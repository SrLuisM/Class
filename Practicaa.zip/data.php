<?php return array (
  0 => 
  array (
    'id' => 1,
    'title' => 'Mr.',
    'name' => 'John',
    'surname' => 'Doe',
    'birthdate' => '30-10-2024',
    'phone' => '123456789',
    'email' => 'john.doe@example.com',
    'favourite' => false,
    'important' => false,
    'archived' => false,
  ),
  1 => 
  array (
    'id' => 2,
    'title' => 'Mrs.',
    'name' => 'Jane',
    'surname' => 'Smith',
    'birthdate' => '30-10-2024',
    'phone' => '987654321',
    'email' => 'jane.smith@example.com',
    'favourite' => false,
    'important' => false,
    'archived' => false,
  ),
  2 => 
  array (
    'id' => 4,
    'title' => 'Miss',
    'name' => 'Lory',
    'surname' => 'Grimes',
    'birthdate' => '30-10-2024',
    'phone' => '666789087',
    'email' => 'logrimes@mail.com',
    'favourite' => false,
    'important' => false,
    'archived' => false,
  ),
  3 => 
  array (
    'id' => 5,
    'title' => 'Mrs.',
    'name' => 'Carlae',
    'surname' => 'Fontana',
    'birthdate' => '30-10-2024',
    'phone' => '444561255',
    'email' => 'carlafon@mail.com',
    'favourite' => false,
    'important' => false,
    'archived' => false,
  ),
  4 => 
  array (
    'id' => 7,
    'title' => 'Mr.',
    'name' => 'Arthur',
    'surname' => 'King',
    'birthdate' => '30-10-2024',
    'phone' => '555444332',
    'email' => 'arthur.king@example.com',
    'favourite' => false,
    'important' => false,
    'archived' => false,
  ),
  5 => 
  array (
    'id' => 8,
    'title' => 'Mr.',
    'name' => 'eee',
    'surname' => 'eeee',
    'birth_date' => '2024-11-15',
    'phone' => '5554334534',
    'email' => 'luismngandia@gmail.com',
    'types' => 
    array (
      0 => 'Favorite',
    ),
    'submit' => '',
  ),
);