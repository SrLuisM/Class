<footer class="footer bg-dark text-white py-4 mt-5">
    <div class="container text-center">
        <span>© 2024 LUIS - PRACTICA 4</span>
    </div>
</footer>
